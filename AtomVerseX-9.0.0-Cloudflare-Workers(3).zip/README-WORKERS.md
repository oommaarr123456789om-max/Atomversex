# AtomVerse X 9.0.0 — Element Forge Edition

## New in 9.0.0
- Element Forge: local educational merge game with atom-count recipes, score, level and persistent collection. Recipes: H₂O, CO₂, NH₃, NaCl, Fe₂O₃ and CH₄. The game validates atom ratios; it is not a laboratory procedure.
- 3D Element Atlas: 118 selectable element entries, each with a dimensional preview tile and a selected-element WebGL specimen viewer with rotation and zoom. The viewer uses a procedural educational material shader; it is not a photogrammetry scan or a guaranteed literal sample for every element. Gas, liquid, radioactive and superheavy entries are represented illustratively.
- Arabic/English UI, touch-friendly controls and local persistence retained from 8.3.0.
- PWA cache bumped to 9.0.0 to prevent stale 8.3.0 app-shell assets.

## Deploy to Cloudflare Pages
Upload the ZIP as a static asset project, or deploy the extracted contents of this directory. `index.html` is at the root.

## Deploy to Cloudflare Workers (Static Assets)
Use the Workers ZIP. It contains `public/index.html`, `public/manifest.webmanifest`, `public/sw.js`, icons and `wrangler.jsonc`. Deploy with Wrangler from the extracted directory.

## Important scientific limits
- 3D visuals are procedural educational visualizations, not laboratory-grade physical scans, crystallographic datasets, or quantum simulations. Not all elements exist as stable visible solids at room temperature.
- Element Forge checks composition counts against a small set of curated formulas. It does not simulate reaction kinetics, thermodynamics, yield, or reaction conditions.
- No cloud accounts, multiplayer, cloud sync, hosted AI, AdSense, payments, or server database are connected.
- All local notes, quiz history, settings and game progress are browser/device-local.

## Runtime
The standalone HTML can be opened directly for core UI, but PWA installation and service-worker offline caching require HTTPS or localhost. WebGL is used for the selected specimen viewer; if unavailable, the 118 visual element tiles remain available.
